import Sort.SortGui;
import Sort.SortManager;

import java.io.IOException;

class asd
{

	public static void main(String[] args) throws IOException
	{
		SortManager manager=new SortManager();
		SortGui G = new SortGui();
		
	}
}