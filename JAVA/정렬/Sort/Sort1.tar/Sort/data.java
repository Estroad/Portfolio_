package Sort;

class data{
	String name;
	int number;

	public data(String name, int number){
		this.name = name;
		this.number = number;
	}
	
	public String getname(){
		return name;
	}

	public int getnum(){
		return number;
	}	
}
