package Phone;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class PhoneGUI extends JFrame{
	
	private JButton add;
	private JButton sea;
	private JButton del;
	private JButton Mre;
	private JButton Mse;
	private JButton ext;
	
	
	public PhoneGUI() {
		setSize(300,450);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("PHONE");
	
		JPanel mainpanel = new JPanel();
		setLayout(new FlowLayout());
		add = new JButton("1.����ó �߰�");
		sea = new JButton("2.����ó �˻�");
		del = new JButton("3.����ó ����");
		Mre = new JButton("4.�޽��� ����");
		Mse = new JButton("5.�޽��� �߽�");
		ext = new JButton("6.������ ����");
		
		add.addActionListener(new addListener());
		sea.addActionListener(new seaListener());
		del.addActionListener(new delListener());
		Mre.addActionListener(new MreListener());
		Mse.addActionListener(new MseListener());
		
		mainpanel.add(add);
		mainpanel.add(sea);
		mainpanel.add(del);
		mainpanel.add(Mre);
		mainpanel.add(Mse);
		mainpanel.add(ext);
		
		
		add(mainpanel);
		
		
		setVisible(true);
	}
private class addListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == add){
			addFGUI a = new addFGUI();
		}
			
		}
	}

private class seaListener implements ActionListener {
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == add){
		//addGUI a = new addGUI();
	}
		
	}
}

private class delListener implements ActionListener {
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == add){
		//addGUI a = new addGUI();
	}
		
	}
}

private class MreListener implements ActionListener {
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == add){
		//addGUI a = new addGUI();
	}
		
	}
}

private class MseListener implements ActionListener {
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == add){
		//addGUI a = new addGUI();
	}
		
	}
}

}


class addFGUI extends JFrame{
	private JButton norm, univ, comp;

	public addFGUI(){
		setSize(300,450);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("PHONE");
		
		JPanel aP = new JPanel();
		
		norm = new JButton("1.�ϡ���");
		univ = new JButton("2.�롡��");
		comp = new JButton("3.ȸ����");
		
		norm.addActionListener(new normListener());
		univ.addActionListener(new univListener());
		comp.addActionListener(new compListener());
		
		aP.add(norm);
		aP.add(univ);
		aP.add(comp);
		
		add(aP);
		setVisible(true);
		
		
	}
	
	private class normListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == norm){
				addNGUI a = new addNGUI();
		}
		}
	}
	private class univListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == univ){
				addUGUI a = new addUGUI();
		}
		}
	}
	private class compListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == comp){
				addCGUI a = new addCGUI();
		}
		}
	}
}
	
class addNGUI extends JFrame{
	private JLabel label1, label2, label3;
	private JTextField text1, text2, text3;
	private JButton submit, reset;
	public addNGUI(){
		setSize(300,450);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("PHONE");
		
		JPanel addPanel = new JPanel();
		text1 = new JTextField(20);
		text2 = new JTextField(20);
		text3 = new JTextField(20);

		label1 = new JLabel("�̡�����");
		label2 = new JLabel("��ȭ��ȣ");
		label3 = new JLabel("I����P");
		
		
		submit = new JButton("�����");
		reset = new JButton("�롡����");
		
		submit.addActionListener(new subListener());
		reset.addActionListener(new resListener());
		
		addPanel.add(label1);
		addPanel.add(text1);
		addPanel.add(label2);
		addPanel.add(text2);
		addPanel.add(label3);
		addPanel.add(text3);
		
		addPanel.add(submit);
		addPanel.add(reset);
		
		add(addPanel);
		setVisible(true);
	}
	
	private class subListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == submit){
			String name=text1.getText();
			String Phone=text2.getText();
			String IPaddress=text3.getText();
			
			PhoneInfo info = new PhoneInfo(name, Phone,IPaddress);
			PhoneBookManager.infoStorage[PhoneBookManager.curCnt++]=info;
			
			PhoneGUI a = new PhoneGUI();
		}
			
		}
	}
	
	private class resListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == reset){
				PhoneGUI a = new PhoneGUI();
		}
			
		}
	}
	
}

class addUGUI extends JFrame{
	private JLabel label1, label2, label3, label4, label5;
	private JTextField text1, text2, text3,text4;
	private JButton submit, reset, up, down;
	private int count =0;
	public addUGUI(){
		setSize(300,450);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("PHONE");
		
		JPanel addPanel = new JPanel();
		text1 = new JTextField(20);
		text2 = new JTextField(20);
		text3 = new JTextField(20);
		text4 = new JTextField(20);
	
		label1 = new JLabel("�̡�����");
		label2 = new JLabel("��ȭ��ȣ");
		label3 = new JLabel("��������");
		label4 = new JLabel("�С�����");
		label5 = new JLabel("I����P");
		
		submit = new JButton("�����");
		reset = new JButton("�롡����");
		up = new JButton("��������");
		down = new JButton("��������");
		
		
		
		submit.addActionListener(new subListener());
		reset.addActionListener(new resListener());
		
		up.addActionListener(new upListener());
		down.addActionListener(new downListener());
		
		
		addPanel.add(label1);
		addPanel.add(text1);
		addPanel.add(label2);
		addPanel.add(text2);
		addPanel.add(label3);
		addPanel.add(text3);
		addPanel.add(up);
		addPanel.add(label5);
		addPanel.add(down);
		addPanel.add(label4);
		addPanel.add(text4);
		
		
		addPanel.add(submit);
		addPanel.add(reset);
		
		add(addPanel);
		setVisible(true);
	}
	
	private class subListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == submit){
			String name=text1.getText();
			String Phone=text2.getText();
			String major=text3.getText();
			int year=count;
			String IPaddress=text4.getText();
			
			PhoneInfo info = new PhoneUnivInfo(name, Phone,major,year,IPaddress);
			PhoneBookManager.infoStorage[PhoneBookManager.curCnt++]=info;
			
			PhoneGUI a = new PhoneGUI();
		}
			
		}
	}
	private class upListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == reset){
				if(count >=0 || count<=4)
				count++;
		}
			
		}
	}
	private class downListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == reset){
				if(count >=0 || count<=4)
					count--;
		}
			
		}
	}
	
	

	
	private class resListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == reset){
				PhoneGUI a = new PhoneGUI();
		}
			
		}
	}
	
	
}

class addCGUI extends JFrame{
	private JLabel label1, label2, label3;
	private JTextField text1, text2, text3;
	private JButton submit, reset;
	public addCGUI(){
		setSize(300,450);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("PHONE");
		
		JPanel addPanel = new JPanel();
		text1 = new JTextField(20);
		text2 = new JTextField(20);
		text3 = new JTextField(20);

		label1 = new JLabel("�̡�����");
		label2 = new JLabel("��ȭ��ȣ");
		label3 = new JLabel("I����P");
		
		
		submit = new JButton("�����");
		reset = new JButton("�롡����");
		
		submit.addActionListener(new subListener());
		reset.addActionListener(new resListener());
		
		addPanel.add(label1);
		addPanel.add(text1);
		addPanel.add(label2);
		addPanel.add(text2);
		addPanel.add(label3);
		addPanel.add(text3);
		
		addPanel.add(submit);
		addPanel.add(reset);
		
		add(addPanel);
		setVisible(true);
	}
	
	private class subListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == submit){
			String name=text1.getText();
			String Phone=text2.getText();
			String IPaddress=text3.getText();
			
			PhoneInfo info = new PhoneInfo(name, Phone,IPaddress);
			PhoneBookManager.infoStorage[PhoneBookManager.curCnt++]=info;
			
			PhoneGUI a = new PhoneGUI();
		}
			
		}
	}
	
	private class resListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == reset){
				PhoneGUI a = new PhoneGUI();
		}
			
		}
	}
	
}




